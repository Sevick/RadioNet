#ifndef TYPES_H
#define TYPES_H



typedef  QVector<QVector<QString> >* RADIOLISTARRAY;

#endif // TYPES_H
